-- AlterTable
ALTER TABLE `proposition` ADD COLUMN `alternative` BOOLEAN NOT NULL DEFAULT false;
