-- AlterTable
ALTER TABLE `user` ADD COLUMN `resetCode` VARCHAR(191) NULL;
