-- AlterTable
ALTER TABLE `module` ADD COLUMN `description` VARCHAR(191) NOT NULL DEFAULT '';
