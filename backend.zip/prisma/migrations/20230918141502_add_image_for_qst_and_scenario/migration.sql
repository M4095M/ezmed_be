-- AlterTable
ALTER TABLE `question` ADD COLUMN `image` VARCHAR(191) NULL;

-- AlterTable
ALTER TABLE `scenario` ADD COLUMN `image` VARCHAR(191) NULL;
