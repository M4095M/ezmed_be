-- AlterTable
ALTER TABLE `question` MODIFY `content` TEXT NOT NULL,
    MODIFY `explication` TEXT NOT NULL;

-- AlterTable
ALTER TABLE `scenario` MODIFY `description` TEXT NOT NULL;
