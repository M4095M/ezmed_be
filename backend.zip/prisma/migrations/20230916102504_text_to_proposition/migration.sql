-- AlterTable
ALTER TABLE `proposition` MODIFY `content` TEXT NOT NULL;
